#!/bin/bash

# Mostrar ayuda
if [[ "$1" == "-help" || "$1" == "--help" ]]; then
    echo "Uso: $0 ORIGEN DESTINO"
    echo "Ejemplo: $0 /var/log /backup_dir"
    exit 0
fi

# Validar cantidad de argumentos
if [[ $# -ne 2 ]]; then
    echo "Error: debe indicar origen y destino."
    echo "Use $0 -help para obtener ayuda."
    exit 1
fi

ORIGEN="$1"
DESTINO="$2"

# Validar que el origen exista
if [[ ! -d "$ORIGEN" || ! -r "$ORIGEN" ]]; then
    echo "Error: el directorio de origen no existe o no es legible."
    exit 1
fi

# Validar el montaje del origen cuando corresponde
if [[ "$ORIGEN" == "/www_dir" ]] && ! mountpoint -q /www_dir; then
    echo "Error: /www_dir no está montado."
    exit 1
fi

if [[ "$DESTINO" != "/backup_dir" ]]; then
    echo "Error: el destino debe ser /backup_dir."
    exit 1
fi

# Validar que el destino exista y sea escribible
if [[ ! -d "$DESTINO" || ! -w "$DESTINO" ]]; then
    echo "Error: el directorio de destino no existe o no permite escritura."
    exit 1
fi

# Verificar que el destino esté montado
if ! mountpoint -q "$DESTINO"; then
    echo "Error: el destino no es un punto de montaje activo."
    exit 1
fi

# Generar nombre del archivo
FECHA=$(date +%Y%m%d)
NOMBRE=$(basename "$ORIGEN")
ARCHIVO="$DESTINO/${NOMBRE}_bkp_${FECHA}.tar.gz"

# Crear backup sin incluir la ruta absoluta
if tar -czf "$ARCHIVO" -C "$(dirname "$ORIGEN")" "$NOMBRE"; then
    echo "Backup generado correctamente: $ARCHIVO"
else
    echo "Error al generar el backup."
    rm -f "$ARCHIVO"
    exit 1
fi

