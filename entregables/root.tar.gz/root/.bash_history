history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
cat /etc/resolv.conf v
powerofff
poweroff
sudo cat /etc/hash 
cd /usr/local/bin/
ls -ltr
ls -l
base64 -d -i < cat /etc/hash 
cat /etc/hash 
cat /etc/hash  > base64 -d -i
cat /etc/hash | base64 -d -i
rm /etc/hash 
chatrr -i /etc/hash 
cd /etc/
ls -l |has
ls -l |hash
ls -ltr 
chatrr +i hash 
chattr -i /etc/hash 
rm /etc/hash 
ls -l
reboot
history
shutdown now
ls
ls
hostnamectl
hostnamectl -h
hostnamectl set-hostname TPServer
hostnamectl
exit
ls -a
cd .ssh
ls
ls -a
cat id_rsa
cat id_rsa.pub 
exit
exit
exit
cd .ssh/
ls
cat authorized_keys 
vim authorized_keys 
exit
exit
cd .ssh/
ls
ls -a
ls -la
vim authorized_keys
ls -la
chmod 600 authorized_keys 
ls -la
cat authorized_keys 
ls
cd
cd /etc/ssh/sshd_config.d/
ls
ls -a
cd ..
ls
vim sshd_config
cd
ls
cat Material_Adicional_TPVMCA.tar.gz 
cls
clear
lsb_release -a
apt update
apt upgrade
apt autoremove
vim
ls
vim /etc/apt/sources.list
vim /etc/apt/sources.list
apt update
ssh
ip a
hostname -I
vim /etc/ssh
cd /etc/ssh/
ls
cd
vim /etc/apt/sources.list
vim /etc/apt/sources.list
vim /etc/apt/sources.list

vim /etc/apt/sources.list
vim /etc/apt/sources.list
apt update
apt update
vim /etc/apt/sources.list
apt update
vim /etc/apt/sources.list
vim /etc/apt/sources.list
apt update
apt full-upgrade 
lsb_release -a
apt install openssh-server
cd /etc/ssh
ls
vim sshd_config
systemctl ssh
systemctl statusssh
systemctl status ssh
systemctl restart ssh
hostname -I
cd
ssh-keygen 
ls
pwd
ls -a
shutdown -h now
shutdown -h now
ls
tar -xvzf Material_Adicional_TPVMCA.tar.gz
ls
cd Material_Adicional_TPVMCA/
ls
ls -la
ls
cd Material_Adicional_TPVMCA/
ls
cat clave_publica.pub 
cat clave_privada.txt 
clear
ls
cd
ls -l /root/.ssh/authorized_keys
cd /root/.ssh/authorized_keys
cd /root/.ssh
ls
cat authorized_keys 
cat /root/Material_Adicional_TPVMCA/clave_publica.pub >> /root/.ssh/authorized_keys
cat authorized_keys 
ls
pwd
chmod 700 /root/.ssh/
cd ..
ls
ls -la
cd .ssh/
ls
ls -la
ls -ld /root/.ssh
ls -l /root/.ssh
exit
cd .ssh/
ls
cat id_rsa.pub 
cat id_rsa
ls
rm /root/.ssh/id_rsa
rm /root/.ssh/id_rsa.pub 
ls
vim authorized_keys 
exit
pwd
ls
ls -la
cd .ssh/
ls
cd ..
ls
ls -la
cd Material_Adicional_TPVMCA/
ls
ls
cd
apt update
apt install apache2 php libapache2-mod-php
cat /etc/debian_version
cat /etc/os-release
systemctl status apache2
php -v
cd /root/.ssh
ls
cd
ls
cd Material_Adicional_TPVMCA/
ls
cat clave_publica.pub 
ls
ls
exit
ls
systemctl status apache2
php -v
ls -l
ls -la
cd Material_Adicional_TPVMCA/
ls
cp /root/Material_Adicional_TPVMCA/index.php /var/www/html/
cp /root/Material_Adicional_TPVMCA/index.php /var/www/html/
cp /root/Material_Adicional_TPVMCA/logo.png /var/www/html/
cd /var/www/html/
ls
ls -l
cd
cd /etc/apache2/mods-enabled/
ls
vim dir.conf 
apache2ctl configtest
vim dir.conf 
vim dir.conf 
apache2ctl configtest
systemctl reload apache2
cd
hostname -I
ls
cd Material_Adicional_TPVMCA/
ls
cat index.php 
reboot
cd Material_Adicional_TPVMCA/
ls
vim index.php 
vim index.php 
apt update
apt install mariadb-server mariadb-client
systemctl status mariadb
systemctl enable --now mariadb
systemctl status mariadb
mariadb --version
mariadb -v
systemctl status mariadb
mariadb
ls
vim db.sql 
vim db.sql 
mariadb < /root/Material_Adicional_TPVMCA/db.sql 
mariadb
systemctl reload mariadb
ls
vim index.php 
php -m | grep -Ei 'mysqli|pdo_mysql'
apt install php-mysql
php -m | grep -Ei 'mysqli|pdo_mysql'
systemctl restart apache2
ip a
ip route 
cat /etc/network/interfaces
cp /etc/network/interfaces /etc/network/interfaces.bak
cd /etc/network/interfaces
cd /etc/network
ls
cat interfaces
cat interfaces.bak 
ip route
vim /etc/network/interfaces
vim /etc/network/interfaces
vim /etc/network/interfaces
ip a
ip route
ping -c 4 192.168.0.1
getent hosts debian.org
lsblk
lsblk
lsblk -o NAME,SIZE,FSTYPE,TYPE,MOUNTPOINTS
cd /dev/sdc
cd /dev/
ls
cat sdc 
ls -a
cd
fdisk /dev/sdc
lsblk
mkfs -t ext4 /dev/sdc1
mkfs -t ext4 /dev/sdc2
mkdir /www_dir
mkdir /backup_dir
ls
pwd
cd ..
ls
cd root/
ls
mount /dev/sdc1 /www_dir
mount /dev/sdc2 /backup_dir/
lsblk -f
df -h
vim /etc/fstab 
cp /etc/fstab /etc/fstab.bak
vim /etc/fstab.bak 
vim /etc/fstab
vim /etc/fstab
systemctl daemon-reload 
findmnt --verify
reboot
lsblk -f
findmnt --verify
ls -l /www_dir/
cp /var/www/html/index.php /www_dir/
cp /var/www/html/logo.png /www_dir/
ls -l /www_dir/
vim /etc/apache2/sites-available/000-default.conf 
vim /etc/apache2/apache2.conf 
vim /etc/apache2/apache2.conf 
ls -l /www_dir/
ls -ld /www_dir/
apache2ctl configtest 
systemctl restart apache2
apache2ctl -S
findmnt /www_dir
getent hosts TPServer
vim /etc/host
vim /etc/host
vim /etc/host
vim /etc/host
vim /etc/host
vim /etc/host
vim /etc/host
ls -l /etc/.host.swp
cd /etc/
vim /etc/.host.swp 
vim /etc/host
vim /etc/host
ls -l /etc/.host.swp
rm /etc/.host.swp
ls -l /etc/.host.swp
vim /etc/host
vim /etc/host
getent hosts TPServer
cd
getent hosts TPServer
vim /etc/apache2/conf-available/servername.conf
vim /etc/apache2/conf-available/servername.conf
a2enconf servername
systemctl reload apache2
a2enconf servername
apache2ctl configtest
getent hosts TPServer
systemctl restart apache2
grep -n DocumentRoot /etc/apache2/sites-enabled/000-default.conf
ls /var/www/html/prueba.txt
findmnt /www_dir
cat /proc/partitions 
cat /proc/partitions > /opt/particion
cat /opt/particion 
diff /proc/partitions /opt/particion
